import React, { useState, useEffect } from 'react';
import TextField from '@mui/material/TextField';

interface NumberFieldProps {
  numberValue: number | string;
  onValueChange: (value: number | string) => void;
  bits: number;
  minValue?: number;
  maxValue?: number;
  floating?: boolean;
  signed?: boolean;
}

const NumberField: React.FC<NumberFieldProps> = ({
                                                   numberValue,
                                                   onValueChange,
                                                   bits,
                                                   minValue = Number.NEGATIVE_INFINITY,
                                                   maxValue = Number.POSITIVE_INFINITY,
                                                   floating = false,
                                                   signed = false,
                                                 }) => {
  const [error, setError] = useState(false);
  const [valueString, setValueString] = useState(numberValue.toString());

  useEffect(() => {
    setValueString(numberValue.toString());
  }, [numberValue]);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    let inputString = event.target.value;

    inputString = inputString.replace(/[^0-9,-.]/g, '');

    if (signed && inputString === '-') {
      onValueChange(-0);
      setValueString('-');
      return;
    }
    if (signed && (inputString === '-' || inputString === '-0' || inputString === '-.')) {
      onValueChange(-0);
      setValueString('-');
      return;
    }

    if (inputString.length > 1 && inputString.indexOf('-') !== 0) {
      inputString = inputString.replace('-', '');
    }
    if (inputString.lastIndexOf(',') !== inputString.indexOf(',')) {
      // если запятая уже есть в числе, удаляем вторую запятую
      inputString = inputString.slice(0, inputString.lastIndexOf(',')) + inputString.slice(inputString.lastIndexOf(',') + 1);
    }
    if (inputString.lastIndexOf('.') !== inputString.indexOf('.')) {
      // если точка уже есть в числе, удаляем вторую точку
      inputString = inputString.slice(0, inputString.lastIndexOf('.')) + inputString.slice(inputString.lastIndexOf('.') + 1);
    }
    if (inputString.lastIndexOf('-') > 0 || (inputString.lastIndexOf('-') === 0 && inputString.lastIndexOf('-') !== inputString.indexOf('-'))) {
      // если минус уже есть в числе, удаляем второй минус
      inputString = inputString.slice(0, inputString.lastIndexOf('-')) + inputString.slice(inputString.lastIndexOf('-') + 1);
    }

    if (floating) {
      inputString = inputString.replace(',', '.');
    }

    const parsedValue = parseFloat(inputString);

    if (isNaN(parsedValue) || parsedValue < minValue || parsedValue > maxValue) {
      setError(true);
    } else {
      setError(false);
      onValueChange(parsedValue);
    }

    setValueString(inputString);
  };


  return (
    <TextField
      type="text"
      value={valueString}
      error={error}
      helperText={error ? 'Invalid value' : ''}
      onChange={handleChange}
      inputProps={{
        maxLength: floating ? 20 : Math.floor(bits / 4),
      }}
    />
  );
};

export default NumberField;
