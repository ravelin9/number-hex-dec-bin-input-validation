import {useState} from "react";
import {TextField, TextFieldProps} from "@mui/material";

type Base = 2 | 10 | 16;
type Format = "int" | "float";

interface BinaryTextFieldProps extends Omit<TextFieldProps, "value" | "onChange"> {
  signed?: boolean;
  bits?: number;
  floating?: boolean;
  minValue?: number;
  maxValue?: number;
  maxHexValue?: string;
  minHexValue?: string;
  onValueChange?: (value: any) => void;
  numberValue?: string | number | undefined;
  format?: Format;
  base?: Base;
}


function BinaryTextField({
                           signed = false,
                           bits = 64,
                           floating = false,
                           minValue,
                           maxValue,
                           maxHexValue,
                           minHexValue,
                           onValueChange,
                           numberValue,
                           format = "int",
                           base = 10,
                           ...props
                         }: BinaryTextFieldProps) {
  const [value, setValue] = useState<any>(() => {
    let num: number | undefined;
    switch (format) {
      case "int":
        if (typeof numberValue === "string") {
          num = parseInt(numberValue, base);
        }else{
          num = numberValue
        }
        break;
      case "float":
        if (typeof numberValue === "string") {
          num = parseFloat(numberValue);
        }else{
          num= numberValue
        }
        break;
    }
    return num;
  });
  const [error, setError] = useState<string>("");

  const handleValueChange = (newValue: string) => {
    let num: number;
    switch (format) {
      case "int":
        num = parseInt(newValue, base);
        break;
      case "float":
        num = parseFloat(newValue);
        break;
    }

    if (isNaN(num)) {
      setValue(undefined);
      setError("Invalid number format");
      return;
    }

    if (base === 16) {
      const hexMax = maxHexValue !== undefined ? parseInt(maxHexValue, 16) : undefined;
      const hexMin = minHexValue !== undefined ? parseInt(minHexValue, 16) : undefined;
      if (hexMax !== undefined && num > hexMax) {
        num = hexMax;
        setError(`The maximum value is ${hexMax.toString(16)}`);
      } else if (hexMin !== undefined && num < hexMin) {

        setError(`The minimum value is ${hexMin.toString(16)}`);
      } else {
        setError("");
      }

      if (bits !== undefined) {
        const max = 2 ** bits - 1;
        if (num > max) {
          num = max;
          setError(`The maximum value for ${bits}-bit is ${max.toString(16)}`);
        }
      }
    } else {
      if (signed) {
        const max = 2 ** (bits - 1) - 1;
        const min = -max - 1;
        if (num > max) {
          num = max;
          setError(`The maximum value is ${max}`);
        } else if (num < min) {
          num = min;
          setError(`The minimum value is ${min}`);
        } else {
          setError("");
        }
      } else {
        const max = 2 ** bits - 1;
        const min = 0;
        if (num > max) {
          num = max;
          setError(`The maximum value is ${max}`);
        } else if (num < min) {
          num = min;
          setError(`The minimum value is ${min}`);
        } else {
          setError("");
        }
      }
    }

    if (minValue !== undefined && num < minValue) {
      setError(`The minimum value is ${minValue}`);
      return;
    }

    if (maxValue !== undefined && num > maxValue) {
      num = maxValue;
      setError(`The maximum value is ${maxValue}`);
    }

    setValue(num);
    if (onValueChange) {
      onValueChange(base === 16 ? `0x${num.toString(16)}` : num.toString());
    }
  };



  return (
    <TextField
      {...props}
      value={value === undefined ? "" : value.toString(base === 16 ? 16 : 10)}
      onChange={(e) => handleValueChange(e.target.value)}
      error={Boolean(error)}
      helperText={error}
    />
  );
}

export default BinaryTextField;
