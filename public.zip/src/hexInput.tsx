import React, { useState, useEffect } from 'react';
import TextField from '@mui/material/TextField';

interface Props {
  numberValue?: string;
  onValueChange?: (value: string) => void;
  bits: number;
  minHexValue?: string;
  maxHexValue?: string;
}

const HexTextField: React.FC<Props> = ({
                                         numberValue = '',
                                         onValueChange,
                                         bits,
                                         minHexValue = '0x0',
                                         maxHexValue = `0x${(2 ** bits - 1).toString(16)}`,
                                       }) => {
  const [value, setValue] = useState<string>(numberValue);

  useEffect(() => {
    if (numberValue !== undefined && numberValue !== '') {
      setValue(numberValue);
    }
  }, [numberValue]);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = event.target.value;

    if (newValue === '') {
      setValue('');
      if (onValueChange) {
        onValueChange('');
      }
    } else if (newValue === '0x') {
      // Input value is the prefix "0x" only
      setValue(newValue);
      if (onValueChange) {
        onValueChange(newValue);
      }
    } else if (newValue.match(/^0x[0-9a-fA-F]*$/)) {
      // Input value is a valid hex number with prefix "0x"
      const intValue = parseInt(newValue, 16);

      if (intValue <= parseInt(maxHexValue, 16)) {
        setValue(newValue);
        if (onValueChange) {
          onValueChange(newValue);
        }
      }
    } else if (newValue.match(/^[0-9a-fA-F]*$/)) {
      // Input value is a valid hex number without prefix "0x"
      const intValue = parseInt(newValue, 16);
      const hexValue = '0x' + newValue; // Add "0x" prefix to the input value

      if (intValue <= parseInt(maxHexValue, 16)) {
        setValue(hexValue);
        if (onValueChange) {
          onValueChange(hexValue);
        }
      }
    }
  };




  return (
    <TextField
      value={value}
      onChange={handleChange}
      error={
        value !== '' &&
        (value.length > maxHexValue.length || parseInt(value, 16) > parseInt(maxHexValue, 16) || parseInt(value, 16) < parseInt(minHexValue, 16))
      }
      helperText={
        value !== '' &&
        (value.length > maxHexValue.length || parseInt(value, 16) > parseInt(maxHexValue, 16) || parseInt(value, 16) < parseInt(minHexValue, 16))
          ? `Value must be between ${minHexValue} and ${maxHexValue}`
          : ''
      }
    />
  );
};

export default HexTextField;
