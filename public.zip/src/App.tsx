import { useState } from 'react'
import './App.css'
import BinaryHexInput from "./Input";

import HexTextField from "./hexInput";
import TextFieldSelector from "./selector";

function App() {
  const [hex, setHex] = useState('0')
  const [dec, setDec] = useState<string | number | undefined>(20)
  const [float, setFloat] = useState(111.888888)
  console.log(dec)

  return (
    <div className="App">
     <BinaryHexInput base={16} bits={64} maxHexValue={'fffffffffffff'} minHexValue={'a'} onValueChange={setHex} numberValue={hex}/>
      <BinaryHexInput bits={64} signed={true} maxValue={99999}  format={'int'} onValueChange={setDec} numberValue={dec}/>
      <BinaryHexInput bits={64} format={'float'} maxValue={111111} minValue={0} numberValue={float} onValueChange={setFloat} />
      <HexTextField bits={32} onValueChange={setHex} numberValue={hex} maxHexValue={'ffffffffff'} minHexValue={'ff'}/>
      <TextFieldSelector bits={64} onValueChange={setDec} numberValue={dec}/>
    </div>
  )
}

export default App
